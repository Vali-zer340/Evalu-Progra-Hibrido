package Calculos_precios

class ItemMenu(val nombre: String, val precio: Int) {
}